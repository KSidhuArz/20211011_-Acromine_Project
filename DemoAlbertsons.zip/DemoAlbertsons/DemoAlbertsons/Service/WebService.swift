//
//  WebService.swift
//  DemoAlbertsons
//
//  Created by Ramandeep Singh on 11/10/21.
//  Copyright © 2021 Kulbir. All rights reserved.
//

import Foundation

class WebService:NSObject {
    static let shared = WebService()
    
    func getList(with url:String, completion: @escaping(Result< Any?, ErrorType>) -> Void)  {
        print(url)
        guard let url = URL(string: url) else{return}
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let _=error {
                completion(.failure(.invalidData))
                return
            }
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else{
                completion(.failure(.invalidResponse))
                return
            }
            guard let data = data else{
                completion(.failure(.invalidData))
                return
            }
            do {
                completion(.success(data))
            }
            catch{
                completion(.failure(.invalidData))
            }
        }
        task.resume()
    }
}
