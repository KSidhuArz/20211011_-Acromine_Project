//
//  ErrorType.swift
//  DemoAlbertsons
//
//  Created by Ramandeep Singh on 11/10/21.
//  Copyright © 2021 Kulbir. All rights reserved.
//

import Foundation

enum ErrorType: String, Error {
    case invalidData = "Sorry. Somthing went wrong, try again"
    case invalidResponse = "Server error. Please modify your search and try again"
}
