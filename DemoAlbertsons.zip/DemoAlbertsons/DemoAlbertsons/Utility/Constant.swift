//
//  Constant.swift
//  DemoAlbertsons
//
//  Created by Ramandeep Singh on 11/10/21.
//  Copyright © 2021 Kulbir. All rights reserved.
//

import Foundation

struct UrlConstant {
    static let getList = "http://www.nactem.ac.uk/software/acromine/dictionary.py?sf="
}
struct Cells{
     static let searchCell = "SearchListTableViewCell"
}
