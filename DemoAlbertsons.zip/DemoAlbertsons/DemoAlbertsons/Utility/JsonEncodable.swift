//
//  JsonEncodable.swift
//  DemoAlbertsons
//
//  Created by Ramandeep Singh on 11/10/21.
//  Copyright © 2021 Kulbir. All rights reserved.
//

import Foundation
open class JsonEncodable {
    
    static func convertJsonToModel<T>(_ type: T.Type, from jsonObj: [String: Any]) -> T? where T: Codable{
        
        do
        {
            let jsonData = try JSONSerialization.data(withJSONObject: jsonObj, options: [])
            return try JSONDecoder().decode(type.self, from: jsonData)
            
        }
        catch{}
        return nil
    }
    
    static func convertJsonsToModel<T>(_ type: T.Type, from jsonObj: [Any]) -> T? where T: Codable{
        
        do
        {
            let jsonData = try JSONSerialization.data(withJSONObject: jsonObj, options: [])
            return try JSONDecoder().decode(type.self, from: jsonData)
            
        }
        catch{}
        return nil
    }
    
    static func convertToModel<T>(_ type: T.Type, from data: Data?) -> T? where T: Codable{
        guard let jsonData = data else{
            return nil
        }
        do
        {
            return try JSONDecoder().decode(type.self, from: jsonData)
        }
        catch
        {}
        return nil
    }
}

extension Encodable {
    var dictionary: [String: Any]?{
        do {
            return try JSONSerialization.jsonObject(with: JSONEncoder().encode(self), options: []) as? [String: Any]
        }
        catch
        {
            return nil
        }
    }
    
    var jsonStrin: String?
    {
        
        do {
            let jsonData = try JSONEncoder().encode(self)
            return String(data: jsonData, encoding: .utf8)
        }
        catch
        {
            return nil
        }
    }
    
}
