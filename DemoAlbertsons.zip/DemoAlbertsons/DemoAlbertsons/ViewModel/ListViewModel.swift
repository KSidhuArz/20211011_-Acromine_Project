//
//  ListViewModel.swift
//  DemoAlbertsons
//
//  Created by Ramandeep Singh on 11/10/21.
//  Copyright © 2021 Kulbir. All rights reserved.
//

import Foundation
class ListViewModel {
    var searchList :[SearchList] = [SearchList]()
    var bindToListTable :(() -> ()) = {}
    func getSearchList(searchStr:String)
        {
            WebService.shared.getList(with: UrlConstant.getList+searchStr) { resultData in
                switch resultData
                {
                case .success(let result):
                    
                let deconder = JSONDecoder()
                if let jsonPetitions = try? deconder.decode([DataSuccess].self, from: result as! Data)
                {
                    if jsonPetitions.count > 0 {
                        self.searchList = jsonPetitions[0].lfs
                    }
                   
                }
                case .failure(let error):
                    print(error)
                }
                self.bindToListTable()
            }
        }
    
}
