//
//  ViewController.swift
//  DemoAlbertsons
//
//  Created by Ramandeep Singh on 11/10/21.
//  Copyright © 2021 Kulbir. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    private var viewModel:ListViewModel = ListViewModel()
    private var dataSource:TableViewDataSource<SearchListTableViewCell,SearchList>!
    @IBOutlet weak var searchTxtFld: UITextField!
    @IBOutlet weak var ListTblView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.viewModel.bindToListTable = {
            self.showData()
        }        
    }
    @IBAction func btnSearchAction(_ sender: Any) {
        searchTxtFld.resignFirstResponder()
        if let strSearch = searchTxtFld.text
        {
            viewModel.getSearchList(searchStr: strSearch)
        }
    }
    func showData()
    {

        self.dataSource = TableViewDataSource(cellIdentifier: Cells.searchCell, items: viewModel.searchList, configureCell: { (cell, item) in
             if let items = item.lf
                              {
                                  cell.searchLbl.text = items
                              }
        })
        DispatchQueue.main.async {
               self.ListTblView.dataSource = self.dataSource
               self.ListTblView.reloadData()
        }

    }

}

