//
//  Acromine.swift
//  DemoAlbertsons
//
//  Created by Ramandeep Singh on 11/10/21.
//  Copyright © 2021 Kulbir. All rights reserved.
//

import Foundation
struct DataSuccess:Codable {
    var lfs:[SearchList]
}
struct SearchList:Codable {
    var lf:String?
}

