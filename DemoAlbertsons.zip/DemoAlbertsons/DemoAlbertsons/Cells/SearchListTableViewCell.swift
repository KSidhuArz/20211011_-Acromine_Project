//
//  SearchListTableViewCell.swift
//  DemoAlbertsons
//
//  Created by Ramandeep Singh on 11/10/21.
//  Copyright © 2021 Kulbir. All rights reserved.
//

import UIKit

class SearchListTableViewCell: UITableViewCell {
    @IBOutlet weak var searchLbl: UILabel!
    
}
